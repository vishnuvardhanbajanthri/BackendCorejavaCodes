package com.capg.corejava.constructor;

public class Employee2 {
	Employee2() {
		System.out.println("Default Constructor");
	}

	public static void main(String[] args) {
		new Employee2();
	}
}
