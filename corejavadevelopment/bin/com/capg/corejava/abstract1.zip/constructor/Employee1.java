package com.capg.corejava.constructor;

public class Employee1 {
	
}
