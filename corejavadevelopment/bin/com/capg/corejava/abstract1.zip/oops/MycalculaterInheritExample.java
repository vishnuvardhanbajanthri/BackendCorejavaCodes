package com.capg.corejava.oops;

public class MycalculaterInheritExample extends Calculater {
	public static void main(String[] args) {
		MycalculaterInheritExample example = new MycalculaterInheritExample();
		example.add();
		example.sub();
		example.div();
		example.multiple();
	}
}
