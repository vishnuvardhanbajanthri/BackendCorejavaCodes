package com.capg.corejava.oops;

public class MyPerson extends Person {
	public static void main(String[] args) {
		MyPerson myPerson = new MyPerson();
		myPerson.personmet();
	}
}
