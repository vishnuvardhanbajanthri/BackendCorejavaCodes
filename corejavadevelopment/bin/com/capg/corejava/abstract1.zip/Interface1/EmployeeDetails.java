package com.capg.corejava.Interface1;

public interface EmployeeDetails {
	public void employeedetails();
}
