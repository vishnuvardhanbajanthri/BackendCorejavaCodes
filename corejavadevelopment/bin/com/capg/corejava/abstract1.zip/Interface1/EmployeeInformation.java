package com.capg.corejava.Interface1;

public interface EmployeeInformation {
	public void employemedicalreport();
}
